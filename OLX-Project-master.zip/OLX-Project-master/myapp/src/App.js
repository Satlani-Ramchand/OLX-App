import React from 'react'
import Routers from './config/Route'

function App() {
  return (
    <>
      <Routers/>
    </>
  );
}

export default App;
